Distanz Running — Brand Assets
==============================

This archive contains the Distanz Running brand marks. All SVGs are
self-hosted-ready; use them directly in web, print, and email contexts.

Folder map
----------
logos/          Full vertical lockup (mark + "Distanz" + "RUNNING")
  logo-full-black.svg     Black mark on transparent — use on light surfaces
  logo-full-white.svg     White mark on transparent — use on dark surfaces

wordmarks/      Horizontal wordmark (mark-as-z + "Distanz")
  wordmark-black.svg      Black on transparent
  wordmark-white.svg      White on transparent
  wordmark-gray.svg       Gray (#8F8F8F) on transparent — tertiary surfaces

symbols/        Mark only (stylised D + two rings) on transparent
  icon-black.svg          Black mark
  icon-white.svg          White mark

badges/         Self-contained mark with its own surface — use when the
                background is unknown or can switch between light and dark
  icon-badge.svg          White surface, solid black mark
  icon-badge-alt.svg      Black surface, solid white mark

app-icons/      1024×1024 masters for App Store / Play Store / PWA
                Ship with square corners; iOS and iPadOS apply their own
                squircle mask at runtime. For macOS export, wrap with the
                platform's rounded-corner radius.
  icon-app.svg            Dark master (black surface, white mark)
  icon-app-alt.svg        Light master (white surface, black mark)

email/          Email-specific logo variants
  logo-full-email.svg     Full logo with outside white stroke — works on
                          both light and dark email backgrounds in a
                          single file (no media-query swap needed)
  logo-email.png          Raster full logo (120×45) — use in email clients
                          that don't render SVG reliably (Gmail, Outlook)

Usage
-----
• Please don't alter the marks or suggest endorsement/sponsorship.
• For questions: brand@distanzrunning.com
• Full guidelines: distanzrunning.com/design-system/distanz-running
